import portfolioHtml from "./imports/portfolio-leonardo-pinheiro.html?raw";

export default function App() {
  return (
    <iframe
      className="portfolio-frame"
      srcDoc={portfolioHtml}
      title="Leonardo Pinheiro | Portfólio"
    />
  );
}
